
package com.seniorproject.smartcontainer;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.seniorproject.smartcontainer.databinding.ActivityLoginBinding;


public class LoginActivity extends AppCompatActivity {


    private ActivityLoginBinding mBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(mBinding.getRoot());

        mBinding.loginBtn.setOnClickListener(view -> {
            login();
        });
    }

    private void login() {
        String email = mBinding.emailETxt.getText().toString().trim();
        String password = mBinding.passwordETxt.getText().toString().trim();

        //CHECK IF username empty or not
        if (email.isEmpty()) {
            mBinding.emailETxt.setError("Email is empty");
            mBinding.emailETxt.requestFocus();
            return;
        }

        //CHECK IF password empty or not
        if (password.isEmpty()) {
            mBinding.passwordETxt.setError("Password is empty");
            mBinding.passwordETxt.requestFocus();
            return;
        }

        //CHECK IF the length of password less then 6
        if (password.length() < 6) {
            mBinding.passwordETxt.setError("Length of password is less than 6");
            mBinding.passwordETxt.requestFocus();
            return;
        }
        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                //redirect to admin profile
                if (email.equals("admin@gmail.com")) {
                    Intent intent = new Intent(LoginActivity.this, AdminActivity.class);
                    startActivity(intent);
                }
                //redirect to amana profile

                if (email.equals("amana@gmail.com")) {
                    Intent intent = new Intent(LoginActivity.this, AmanaActivity.class);
                    startActivity(intent);
                }
                //redirect to cleaner profile
            } else {
                Toast.makeText(LoginActivity.this, "Please Check Your login Credentials", Toast.LENGTH_SHORT).show();
            }
        });
    }

}

