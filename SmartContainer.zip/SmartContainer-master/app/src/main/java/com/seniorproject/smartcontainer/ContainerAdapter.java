package com.seniorproject.smartcontainer;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.seniorproject.smartcontainer.databinding.CardviewContainerBinding;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;


public class ContainerAdapter extends RecyclerView.Adapter<ContainerAdapter.MyViewHolder> {

    // Variable declaration
    private Context mContext;
    private List<ContainerModel> mData;
    private OnClick mOnClick;


    public ContainerAdapter(List<ContainerModel> data, OnClick onClick) {
        mData = data;
        mOnClick = onClick;
    }


    @NonNull
    @Override
    public ContainerAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        mContext = parent.getContext();
        CardviewContainerBinding binding = CardviewContainerBinding.inflate(LayoutInflater.from(mContext), parent, false);
        return new MyViewHolder(binding.getRoot());
    }

    @Override
    public void onBindViewHolder(@NonNull final ContainerAdapter.MyViewHolder holder, final int position) {

        ContainerModel model = mData.get(position);

        //Preparing time with desired format
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(model.getCreationDate());
        SimpleDateFormat formatter = new SimpleDateFormat("dd MMM hh:mm aaa", Locale.ENGLISH);
        String dateString = formatter.format(calendar.getTime());

        holder.mBinding.itemIDTxtV.setText(model.getContainerID());
        holder.mBinding.creationTimeTxtV.setText(dateString);
        holder.mBinding.locationTxtV.setText(model.getLat() + ", " + model.getLng());

        holder.mBinding.parentCV.setOnClickListener(view -> mOnClick.onClick(position));
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        CardviewContainerBinding mBinding;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            mBinding = CardviewContainerBinding.bind(itemView);
        }
    }
}

