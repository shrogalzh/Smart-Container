package com.seniorproject.smartcontainer;

import com.google.firebase.database.Exclude;

public class ContainerModel {

    public static final String CONTAINER = "Container";
    public static final String CREATOR_ID = "creatorID";

    @Exclude
    private String containerID;

    private long creationDate;
    private String creatorID;
    private double lat;
    private double lng;

    public ContainerModel() {
    }

    public String getContainerID() {
        return containerID;
    }

    public void setContainerID(String containerID) {
        this.containerID = containerID;
    }

    public long getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(long creationDate) {
        this.creationDate = creationDate;
    }

    public String getCreatorID() {
        return creatorID;
    }

    public void setCreatorID(String creatorID) {
        this.creatorID = creatorID;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }
}
