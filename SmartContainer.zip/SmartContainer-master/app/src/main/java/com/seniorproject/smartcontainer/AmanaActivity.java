package com.seniorproject.smartcontainer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.seniorproject.smartcontainer.databinding.ActivityAmanaBinding;

public class AmanaActivity extends AppCompatActivity {

    private ActivityAmanaBinding mBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = ActivityAmanaBinding.inflate(getLayoutInflater());
        setContentView(mBinding.getRoot());

        mBinding.registrationBtn.setOnClickListener(view -> {
            Intent intent = new Intent(AmanaActivity.this, SignupActivity.class);
            startActivity(intent);
        });
    }
}