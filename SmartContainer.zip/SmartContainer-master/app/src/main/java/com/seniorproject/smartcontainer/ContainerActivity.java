package com.seniorproject.smartcontainer;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;

import com.seniorproject.smartcontainer.databinding.ActivityAmanaBinding;
import com.seniorproject.smartcontainer.databinding.ActivityContainerBinding;

public class ContainerActivity extends AppCompatActivity {

    private ActivityContainerBinding mBinding;
    private Context mContext;
    private ProgressDialog mProgressDialog;
    private FirebaseDatabaseManager mDatabaseManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = ActivityContainerBinding.inflate(getLayoutInflater());
        setContentView(mBinding.getRoot());

        mContext = ContainerActivity.this;
        mProgressDialog = new ProgressDialog(mContext);
        mProgressDialog.setMessage("Loading");
        mDatabaseManager = new FirebaseDatabaseManager();


        mBinding.floatingActionButton.setOnClickListener(view -> {
            mProgressDialog.show();
            mDatabaseManager.addContainer(21.562686, 39.208139, success -> {
                mProgressDialog.cancel();
                String message = success ? "Container added successfully" : "Something went wrong";
                Toast.makeText(mContext, message, Toast.LENGTH_LONG).show();
            });
        });

        getContainersListener();
    }

    private void getContainersListener() {
        mProgressDialog.show();
        mDatabaseManager.getContainersListener(containerModels -> {
            mProgressDialog.cancel();
            ContainerAdapter adapter = new ContainerAdapter(containerModels, position -> {
                String location = containerModels.get(position).getLat() + ", " + containerModels.get(position).getLng();
                GoogleMapManager.showLocationOnMap(mContext, location);
            });

            mBinding.recyclerview.setAdapter(adapter);
            mBinding.recyclerview.setLayoutManager(new GridLayoutManager(mContext, 1));
        });
    }
}