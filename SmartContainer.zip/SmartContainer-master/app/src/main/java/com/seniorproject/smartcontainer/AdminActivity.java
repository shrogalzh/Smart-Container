package com.seniorproject.smartcontainer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.seniorproject.smartcontainer.databinding.ActivityAdminBinding;

public class AdminActivity extends AppCompatActivity {

    private ActivityAdminBinding mBinding;
    private Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = ActivityAdminBinding.inflate(getLayoutInflater());
        setContentView(mBinding.getRoot());

        mContext = AdminActivity.this;

        mBinding.optimalPathBtn.setOnClickListener(view -> startActivity(new Intent(mContext, OptimalPath.class)));
        mBinding.modifyContainerBtn.setOnClickListener(view -> startActivity(new Intent(mContext, ContainerActivity.class)));

    }
}
