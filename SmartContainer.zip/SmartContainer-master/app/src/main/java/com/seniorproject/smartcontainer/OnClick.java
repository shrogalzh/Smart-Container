package com.seniorproject.smartcontainer;

public interface OnClick {
    void onClick(int position);
}
