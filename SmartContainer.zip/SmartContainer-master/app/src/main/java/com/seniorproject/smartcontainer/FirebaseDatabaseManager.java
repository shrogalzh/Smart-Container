package com.seniorproject.smartcontainer;

import android.util.Log;

import androidx.annotation.NonNull;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class FirebaseDatabaseManager {
    public static final String TAG = "Firebase Controller";

    private FirebaseDatabase mDatabase;
    public static final String USER_ID = FirebaseAuth.getInstance().getCurrentUser().getUid();

    public FirebaseDatabaseManager() {
        mDatabase = FirebaseDatabase.getInstance();
    }

    //Method to  add Container to firebase
    public void addContainer(double lat, double lng, OnSuccess onSuccess) {
        try {
            ContainerModel model = new ContainerModel();
            model.setCreationDate(System.currentTimeMillis());
            model.setCreatorID(USER_ID);
            model.setLat(lat);
            model.setLng(lng);
            String newID = mDatabase.getReference().push().getKey();
            mDatabase.getReference(ContainerModel.CONTAINER).child(newID).setValue(model).addOnSuccessListener(unused -> onSuccess.onSuccess(true)).addOnFailureListener(e -> {
                onSuccess.onSuccess(false);
                Log.e(TAG, "Error: " + e.getMessage());
            });

        } catch (Exception e) {
            Log.e(TAG, "Error: " + e.getMessage());
        }
    }

    public interface OnSuccess {
        void onSuccess(boolean success);
    }


    interface OnContainerRetrieved {
        void onRetrieved(List<ContainerModel> containerModels);
    }

    public void getContainersListener(final OnContainerRetrieved onContainerRetrieved) {
        mDatabase.getReference(ContainerModel.CONTAINER).orderByChild(ContainerModel.CREATOR_ID).equalTo(USER_ID)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        List<ContainerModel> containerModels = new ArrayList<>();
                        if (dataSnapshot.exists()) {
                            for (DataSnapshot keyNode : dataSnapshot.getChildren()) {
                                ContainerModel containerModel = keyNode.getValue(ContainerModel.class);
                                containerModel.setContainerID(keyNode.getKey());
                                containerModels.add(containerModel);
                            }
                        }
                        onContainerRetrieved.onRetrieved(containerModels);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        onContainerRetrieved.onRetrieved(new ArrayList<>());
                        Log.e(TAG, "Error: " + databaseError.getMessage());
                    }
                });
    }

}
