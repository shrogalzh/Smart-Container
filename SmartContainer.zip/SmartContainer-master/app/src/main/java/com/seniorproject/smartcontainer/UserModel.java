package com.seniorproject.smartcontainer;

import android.widget.EditText;

public class UserModel {

    public String username, Password, Email, phone_Number;

    public UserModel(String username, String phone_Number, String Email, String Password) {
        this.username = username;
        this.Password = Password;
        this.phone_Number = phone_Number;
        this.Email = Email;
    }

}
