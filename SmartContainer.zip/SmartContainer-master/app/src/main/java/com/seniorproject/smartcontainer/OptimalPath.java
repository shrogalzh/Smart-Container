package com.seniorproject.smartcontainer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.seniorproject.smartcontainer.databinding.ActivityOptimalPathBinding;

public class OptimalPath extends AppCompatActivity {

    private ActivityOptimalPathBinding mBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = ActivityOptimalPathBinding.inflate(getLayoutInflater());
        setContentView(mBinding.getRoot());


        mBinding.displayBtn.setOnClickListener(view -> {
            displayTrack();
        });
    }

    private void displayTrack() {
        //get value from edit text
        String source = mBinding.sourceETxt.getText().toString().trim();
        String destination = mBinding.destinationETxt.getText().toString().trim();

        //check condition

        //CHECK IF field empty or not
        if (source.isEmpty()) {
            mBinding.sourceETxt.setError("Source is empty");
            mBinding.sourceETxt.requestFocus();
            return;
        }

        if (destination.isEmpty()) {
            mBinding.destinationETxt.setError("Destination number is empty");
            mBinding.destinationETxt.requestFocus();
            return;
        }

        //if the device does not have a map installed,then redirect it to play store
        try {
            //when google map is installed
            //Initialize uri
            Uri uri = Uri.parse("https://www.google.co.in/maps/dir/" + source + "/ " + destination);
            //initialize intent with action view

            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            //set packege
            intent.setPackage("com.google.android.apps.maps");
            //set flag
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            //start activity
            startActivity(intent);

        } catch (ActivityNotFoundException e) {
            //when google map is not installed
            //Initialize uri
            Uri uri = Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.apps.maps");

            //Initialize intent with action view
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            //set flag
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            //start activity
            startActivity(intent);
        }
    }
}

 
