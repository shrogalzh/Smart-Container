package com.seniorproject.smartcontainer;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

public class GoogleMapManager {

    public static void showDirectionOnMap(Context context, String source, String destination) {
        Uri uri = Uri.parse("https://www.google.co.in/maps/dir/" + source + "/ " + destination);
        startGoogleMapApp(context, uri);
    }

    public static void showLocationOnMap(Context context, String location) {
        Uri uri = Uri.parse("https://www.google.com/maps/search/?api=1&query=" + location);
        startGoogleMapApp(context, uri);
    }

    private static void startGoogleMapApp(Context context, Uri uri) {
        //if the device does not have a map installed,then redirect it to play store
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            //set packege
            intent.setPackage("com.google.android.apps.maps");
            //set flag
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            //start activity
            context.startActivity(intent);

        } catch (ActivityNotFoundException e) {
            //when google map is not installed
            //Initialize uri
            Uri uri2 = Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.apps.maps");

            //Initialize intent with action view
            Intent intent = new Intent(Intent.ACTION_VIEW, uri2);
            //set flag
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            //start activity
            context.startActivity(intent);
        }
    }

}
