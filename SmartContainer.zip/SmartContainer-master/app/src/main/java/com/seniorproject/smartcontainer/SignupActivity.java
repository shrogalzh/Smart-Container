

package com.seniorproject.smartcontainer;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.seniorproject.smartcontainer.databinding.ActivitySignupBinding;

public class SignupActivity extends AppCompatActivity {

    private ActivitySignupBinding mBinding;
    private ProgressDialog mProgressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = ActivitySignupBinding.inflate(getLayoutInflater());
        setContentView(mBinding.getRoot());

        mProgressDialog = new ProgressDialog(this);

        mBinding.signupBtn.setOnClickListener(view -> {
            signup();
        });

    }


    private void signup() {
        String name = mBinding.nameETxt.getText().toString().trim();
        String password = mBinding.passwordETxt.getText().toString().trim();
        String phone = mBinding.phoneETxt.getText().toString().trim();
        String email = mBinding.emailETxt.getText().toString().trim();


        //CHECK IF field empty or not
        if (name.isEmpty()) {
            mBinding.nameETxt.setError("Name is empty");
            mBinding.nameETxt.requestFocus();
            return;
        }

        if (phone.isEmpty()) {
            mBinding.phoneETxt.setError("Phone number is empty");
            mBinding.phoneETxt.requestFocus();
            return;
        }

        if (email.isEmpty()) {
            mBinding.emailETxt.setError("Email is empty");
            mBinding.emailETxt.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            mBinding.passwordETxt.setError("Password is empty");
            mBinding.passwordETxt.requestFocus();
            return;
        }


        //CHECK IF the length of password more then 6
        if (password.length() > 6) {
            mBinding.passwordETxt.setError("Length of password is should be more than 6");
            mBinding.passwordETxt.requestFocus();
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            mBinding.emailETxt.setError("Enter the valid Email");
            mBinding.emailETxt.requestFocus();
            return;
        }

        mProgressDialog.show();

        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password).addOnCompleteListener(task -> {
            if (!task.isSuccessful()) {
                Toast.makeText(SignupActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
                mProgressDialog.cancel();
                return;
            }
            UserModel UserModel = new UserModel(name, phone, password, email);
            FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(UserModel).addOnCompleteListener(task1 -> {
                mProgressDialog.cancel();
                if (!task1.isSuccessful()) {
                    Toast.makeText(SignupActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
                    return;
                }
                Toast.makeText(SignupActivity.this, "User has been registered successful", Toast.LENGTH_SHORT).show();
                finish();
            });

        });
    }


}


