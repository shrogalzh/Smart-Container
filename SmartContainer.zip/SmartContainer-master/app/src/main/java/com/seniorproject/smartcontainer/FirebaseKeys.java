package com.seniorproject.smartcontainer;

import com.google.firebase.auth.FirebaseAuth;

public class FirebaseKeys {


    public static final String CLIENT = "Client";
    public static final String ACCOUNTS = "Accounts";
    public static final String ACCOUNT_TYPE = "accountType";
    public static final String FEMALE = "Female";
    public static final String MALE = "Male";
    public static final String ORDERS = "Orders";
    public static final String HELPER_ID = "helperID";
    public static final String CLIENT_ID = "clientID";
    public static final String HELPER_STATUS = "helperStatus";
    public static final String RATING = "rating";

    //Helper Status
    public static final String AVAILABLE = "Available";
    public static final String BUSY = "Busy";


    //Categories
    public static final String EMPTY = "Empty";
    public static final String BABYSITTER = "Baby Sitter";
    public static final String ELDERLY_CARE = "Elderly Care";
    public static final String DISABLED_CARE = "Disabled Care";
    public static final String CATEGORY4 = "Category 4";
    public static final String CATEGORY5 = "Category 5";
    public static final String CATEGORY6 = "Category 6";

    //Order Status
    public static final String PENDING = "Pending";
    public static final String ACCEPTED = "Accepted";
    public static final String DECLINED = "Declined";
    public static final String FINISHED = "Finished";
    public static final String FINISHED_AND_RATED = "Finished and Rated";


    //Chat Keys
    public static final String CHAT_REFERENCE = "chat";
    public static final String TEXT = "Text";
    public static final String IMAGE = "Image";
    public static final String CREATION_DATE = "creationDate";

}
